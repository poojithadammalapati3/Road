"""
SafeDrive AI - Smart Road Safety & Emergency Response System
------------------------------------------------------------
Hackathon prototype built with Python + Streamlit.

Modules
  1. Driver monitoring  (OpenCV Haar cascades - no GPU, no model downloads)
  2. Accident detection (manual simulation / image upload)
  3. Emergency dashboard
  4. Accident map       (Folium)
  5. SOS alert          (SMTP email, optional Twilio SMS, Demo Mode fallback)
  6. Response tracking  (judge-controlled status dropdown)

Run:  streamlit run app.py
"""

import os
import smtplib
import time
from datetime import datetime
from email.message import EmailMessage

import cv2
import folium
import numpy as np
import streamlit as st
from PIL import Image
from streamlit_folium import st_folium

# Load variables from a local .env file if python-dotenv is installed (optional)
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

# ----------------------------------------------------------------------------
# PAGE CONFIG + STYLE
# ----------------------------------------------------------------------------
st.set_page_config(page_title="SafeDrive AI", page_icon="🚗", layout="wide")

st.markdown(
    """
    <style>
    .hero {background: linear-gradient(90deg,#0f2027,#203a43,#2c5364);
           padding: 1.4rem 1.8rem; border-radius: 14px; color: white; margin-bottom: 1rem;}
    .hero h1 {margin: 0; font-size: 2rem; color: white;}
    .hero p {margin: .3rem 0 0 0; opacity: .85;}
    .card {background: rgba(128,128,128,.10); padding: 1rem 1.2rem;
           border-radius: 12px; margin-bottom: .8rem;}
    </style>
    """,
    unsafe_allow_html=True,
)

RESPONSE_STEPS = [
    ("Alert Sent", "🟢"),
    ("Emergency Team Notified", "🟡"),
    ("Help En Route", "🔵"),
    ("Assistance Arrived", "🟢"),
]
RESPONSE_NAMES = [s[0] for s in RESPONSE_STEPS]


# ----------------------------------------------------------------------------
# CONFIG HELPERS  (secrets are NEVER hard-coded)
# ----------------------------------------------------------------------------
def get_cfg(key: str, default: str = "") -> str:
    """Read a setting from .streamlit/secrets.toml first, then environment variables."""
    try:
        if key in st.secrets:
            return str(st.secrets[key])
    except Exception:  # no secrets file present
        pass
    return os.getenv(key, default)


# ----------------------------------------------------------------------------
# SESSION STATE (acts as our tiny in-memory database)
# ----------------------------------------------------------------------------
DEFAULTS = {
    "driver_status": "SAFE",
    "distraction_start": None,
    "distraction_seconds": 0,
    "distraction_reason": "-",
    "distraction_events": 0,
    "event_log": [],
    "accident": None,  # dict once an accident is detected
    "sos_sent": False,
    "response_status": None,  # None -> STANDBY
    "alert_history": [],
    # user-editable settings (bound to widgets via key=)
    "lat": 14.4673,
    "lon": 78.8242,
    "location_name": "Kadapa, Andhra Pradesh",
    "contact_phone": get_cfg("EMERGENCY_CONTACT_PHONE", "+91 XXXXX XXXXX"),
    "demo_mode": True,
    "auto_sos": True,
    "threshold": 3,
    "eyes_limit": 2,
}
for k, v in DEFAULTS.items():
    st.session_state.setdefault(k, v)


def reset_demo():
    """Clear everything except settings."""
    for k in [
        "driver_status", "distraction_start", "distraction_seconds", "distraction_reason",
        "distraction_events", "event_log", "accident", "sos_sent", "response_status",
        "alert_history",
    ]:
        st.session_state[k] = DEFAULTS[k] if not isinstance(DEFAULTS[k], list) else []


# ----------------------------------------------------------------------------
# SOS MODULE
# ----------------------------------------------------------------------------
def send_sos() -> tuple[bool, str]:
    """
    Send the SOS alert. Order of preference:
      1. Demo mode ON  -> simulate only
      2. Twilio SMS if credentials exist
      3. SMTP email   if credentials exist
      4. No credentials -> fall back to simulation
    """
    acc = st.session_state.accident
    where = acc["location"] if acc else st.session_state.location_name
    when = acc["time"] if acc else datetime.now().strftime("%I:%M %p")
    maps_link = f"https://www.google.com/maps?q={st.session_state.lat},{st.session_state.lon}"
    body = (
        "SOS ALERT - SafeDrive AI\n"
        f"Accident location: {where}\n"
        f"Coordinates: {st.session_state.lat}, {st.session_state.lon}\n"
        f"Time: {when}\n"
        f"Map: {maps_link}\n"
        "Immediate assistance required."
    )

    ok, detail = True, "✅ SOS alert simulated successfully"

    if not st.session_state.demo_mode:
        sid, token = get_cfg("TWILIO_ACCOUNT_SID"), get_cfg("TWILIO_AUTH_TOKEN")
        from_no, to_no = get_cfg("TWILIO_FROM_NUMBER"), get_cfg("EMERGENCY_CONTACT_PHONE")
        smtp_host, smtp_user = get_cfg("SMTP_HOST"), get_cfg("SMTP_USER")
        smtp_pass, mail_to = get_cfg("SMTP_PASSWORD"), get_cfg("ALERT_TO_EMAIL")

        try:
            if sid and token and from_no and to_no:
                from twilio.rest import Client  # optional dependency

                Client(sid, token).messages.create(body=body, from_=from_no, to=to_no)
                detail = f"✅ SMS sent to {to_no}"
            elif smtp_host and smtp_user and smtp_pass and mail_to:
                msg = EmailMessage()
                msg["Subject"] = "🚨 SafeDrive AI - SOS ALERT"
                msg["From"], msg["To"] = smtp_user, mail_to
                msg.set_content(body)
                with smtplib.SMTP(smtp_host, int(get_cfg("SMTP_PORT", "587")), timeout=15) as s:
                    s.starttls()
                    s.login(smtp_user, smtp_pass)
                    s.send_message(msg)
                detail = f"✅ Email sent to {mail_to}"
            else:
                detail = "⚠️ No credentials found - SOS simulated (Demo fallback)"
        except Exception as e:  # never crash the demo because of a network problem
            ok, detail = False, f"❌ Sending failed: {e}"

    st.session_state.alert_history.insert(
        0,
        {
            "time": datetime.now().strftime("%d %b %Y, %I:%M:%S %p"),
            "contact": st.session_state.contact_phone,
            "location": where,
            "result": detail,
        },
    )
    if ok:
        st.session_state.sos_sent = True
        if st.session_state.response_status is None:
            st.session_state.response_status = RESPONSE_NAMES[0]
    return ok, detail


# ----------------------------------------------------------------------------
# ACCIDENT MODULE
# ----------------------------------------------------------------------------
def trigger_accident(severity: str, source: str):
    """Register an accident and (optionally) fire the SOS automatically."""
    st.session_state.accident = {
        "location": st.session_state.location_name,
        "lat": st.session_state.lat,
        "lon": st.session_state.lon,
        "time": datetime.now().strftime("%I:%M %p"),
        "severity": severity,
        "source": source,
        "status": "Emergency Response Required",
    }
    st.session_state.sos_sent = False
    st.session_state.response_status = None
    if st.session_state.auto_sos:
        send_sos()


# ----------------------------------------------------------------------------
# DRIVER MONITORING (OpenCV Haar cascades - lightweight, runs on any laptop)
# ----------------------------------------------------------------------------
@st.cache_resource
def load_cascades():
    base = cv2.data.haarcascades
    return {
        "face": cv2.CascadeClassifier(base + "haarcascade_frontalface_default.xml"),
        "profile": cv2.CascadeClassifier(base + "haarcascade_profileface.xml"),
        "eye": cv2.CascadeClassifier(base + "haarcascade_eye.xml"),
    }


def analyze_frame(frame, cascades):
    """
    Returns a dict describing the driver state in this frame and draws on the frame.
      face      : frontal face found  -> driver looking forward
      profile   : only side face found -> driver looking away
      eyes      : at least one eye found inside the face
      head_down : face sits low in the image -> heuristic for phone use
    """
    h, w = frame.shape[:2]
    gray = cv2.equalizeHist(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
    out = {"face": False, "profile": False, "eyes": False, "head_down": False}

    faces = cascades["face"].detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
    if len(faces) > 0:
        x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])  # largest face = driver
        out["face"] = True
        cv2.rectangle(frame, (x, y), (x + fw, y + fh), (0, 200, 0), 2)

        # eyes live in the upper half of the face
        roi = gray[y : y + fh // 2, x : x + fw]
        eyes = cascades["eye"].detectMultiScale(roi, 1.1, 6, minSize=(18, 18))
        out["eyes"] = len(eyes) > 0
        for ex, ey, ew, eh in eyes:
            cv2.rectangle(frame, (x + ex, y + ey), (x + ex + ew, y + ey + eh), (255, 200, 0), 2)

        # Heuristic: head tilted down / face low in frame => possible phone use
        out["head_down"] = (y + fh / 2) > 0.62 * h
    else:
        # try side faces (both directions by flipping the image)
        side = cascades["profile"].detectMultiScale(gray, 1.2, 4, minSize=(80, 80))
        if len(side) == 0:
            side = cascades["profile"].detectMultiScale(cv2.flip(gray, 1), 1.2, 4, minSize=(80, 80))
        if len(side) > 0:
            out["profile"] = True
    return out


def get_frame(cap):
    """Real webcam frame, or a synthetic placeholder when no camera is available."""
    if cap is not None:
        ok, frame = cap.read()
        if ok:
            return cv2.flip(frame, 1)
    frame = np.zeros((360, 640, 3), dtype=np.uint8)
    cv2.putText(frame, "DEMO FEED - no camera", (150, 190), cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
    return frame


# ----------------------------------------------------------------------------
# SMALL UI HELPERS
# ----------------------------------------------------------------------------
def overall_status():
    """Values shown in the top metric row on several pages."""
    acc = st.session_state.accident
    driver = "ALERT" if acc else st.session_state.driver_status
    acc_txt = "ACCIDENT DETECTED" if acc else "NO ACCIDENT"
    if not acc:
        resp = "STANDBY"
    elif st.session_state.sos_sent:
        resp = "SOS SENT" if st.session_state.response_status == RESPONSE_NAMES[0] else \
            st.session_state.response_status.upper()
    else:
        resp = "SOS PENDING"
    return driver, acc_txt, resp


def metric_row():
    d, a, r = overall_status()
    c1, c2, c3 = st.columns(3)
    c1.metric("Driver Status", d)
    c2.metric("Accident Status", a)
    c3.metric("Response Status", r)


def response_tracker():
    current = st.session_state.response_status
    idx = RESPONSE_NAMES.index(current) if current in RESPONSE_NAMES else -1
    st.markdown("**SOS Status:**")
    for i, (name, icon) in enumerate(RESPONSE_STEPS):
        st.markdown(f"{icon if i <= idx else '⚪'} {name}")


def hero(title, sub):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{sub}</p></div>', unsafe_allow_html=True)


# ----------------------------------------------------------------------------
# SIDEBAR - navigation + global settings
# ----------------------------------------------------------------------------
with st.sidebar:
    st.title("🚗 SafeDrive AI")
    page = st.radio(
        "Navigate",
        ["🏠 Home", "📷 Driver Monitoring", "🚨 Accident Detection",
         "🗺️ Emergency Dashboard", "📞 Emergency Alert"],
    )
    st.divider()
    st.subheader("⚙️ Settings")
    st.toggle("Demo Mode (no real SMS / email)", key="demo_mode")
    st.toggle("Auto-send SOS on accident", key="auto_sos")
    st.number_input("Distraction alert after (seconds)", 1, 30, key="threshold")
    st.number_input("Eyes-closed limit (seconds)", 1, 10, key="eyes_limit")
    st.text_input("Location name", key="location_name")
    st.number_input("Latitude", format="%.4f", key="lat")
    st.number_input("Longitude", format="%.4f", key="lon")
    st.text_input("Emergency contact", key="contact_phone")
    if st.button("♻️ Reset demo", use_container_width=True):
        reset_demo()
        st.rerun()


# ----------------------------------------------------------------------------
# PAGE: HOME
# ----------------------------------------------------------------------------
if page == "🏠 Home":
    hero("SafeDrive AI", "Smart Road Safety & Emergency Response System")
    metric_row()

    left, right = st.columns(2)
    with left:
        st.subheader("The problem")
        st.markdown(
            """
            Road accidents are often caused by:
            1. **Driver distraction** - phone use, drowsiness, looking away
            2. **Obstacles** on the road
            3. **Delayed emergency response** after a crash

            Every minute saved in reaching the injured can save a life.
            """
        )
    with right:
        st.subheader("How SafeDrive AI helps")
        st.markdown(
            """
            - 📷 **Watches the driver** through a webcam and warns on distraction
            - 🚨 **Detects an accident** and records location, time and severity
            - 📞 **Sends an instant SOS** to the emergency contact
            - 🗺️ **Shows the location** on a live map for responders
            - 🟢 **Tracks the response** from alert to assistance arrival
            """
        )

    st.subheader("System workflow")
    st.code(
        "Camera → Driver Monitoring → Distraction? → Warn Driver\n"
        "       → Accident Detected? → Get Location → Update Dashboard\n"
        "       → Trigger SOS → Notify Contact → Track Response",
        language="text",
    )
    st.info("💡 Quick demo: open **Accident Detection** → press *Simulate Accident* → "
            "view the **Emergency Dashboard** → change the response status.")


# ----------------------------------------------------------------------------
# PAGE: DRIVER MONITORING
# ----------------------------------------------------------------------------
elif page == "📷 Driver Monitoring":
    hero("📷 Driver Monitoring", "Live camera analysis for distraction detection")

    c_top1, c_top2, c_top3 = st.columns(3)
    run = c_top1.toggle("▶️ Start camera", key="run_cam")
    force = c_top2.toggle("🧪 Simulate distraction (demo)", key="force_distraction")
    cam_index = c_top3.number_input("Camera index", 0, 5, 0)

    m1, m2 = st.columns([3, 2])
    video_ph = m1.empty()
    with m2:
        status_ph = st.empty()
        alert_ph = st.empty()
        st.caption(f"Distraction events this session: {st.session_state.distraction_events}")
        with st.expander("Event log"):
            for e in st.session_state.event_log[:10]:
                st.write(e)

    if not run:
        status_ph.markdown(f"### Driver Status: {'🔴 DISTRACTED' if st.session_state.driver_status == 'DISTRACTED' else '🟢 SAFE'}")
        video_ph.info("Turn on **Start camera** to begin monitoring. "
                      "No webcam? Use the demo distraction switch.")
    else:
        cascades = load_cascades()
        cap = cv2.VideoCapture(int(cam_index))
        if not cap.isOpened():
            cap = None
            st.warning("Webcam not found - showing a demo feed. Use *Simulate distraction* to test alerts.")

        eyes_closed_since = None
        alert_fired = False  # so each distraction episode is counted once
        try:
            # Loop ends automatically when the user flips the toggle (Streamlit reruns the script)
            while True:
                now = time.time()
                frame = get_frame(cap)
                res = analyze_frame(frame, cascades) if cap is not None else \
                    {"face": True, "profile": False, "eyes": True, "head_down": False}

                # --- eyes-closed timer ---
                if res["face"] and not res["eyes"]:
                    eyes_closed_since = eyes_closed_since or now
                else:
                    eyes_closed_since = None
                eyes_closed = eyes_closed_since is not None and (now - eyes_closed_since) >= st.session_state.eyes_limit

                # --- collect distraction reasons ---
                reasons = []
                if force:
                    reasons.append("Simulated distraction")
                if cap is not None:
                    if not res["face"] and not res["profile"]:
                        reasons.append("Face not detected")
                    if res["profile"]:
                        reasons.append("Looking away from road")
                    if eyes_closed:
                        reasons.append("Eyes closed for a long period")
                    if res["head_down"]:
                        reasons.append("Possible phone use (head down)")
                distracted = bool(reasons)

                # --- distraction duration ---
                if distracted:
                    if st.session_state.distraction_start is None:
                        st.session_state.distraction_start = now
                    duration = now - st.session_state.distraction_start
                else:
                    st.session_state.distraction_start = None
                    duration, alert_fired = 0, False

                st.session_state.driver_status = "DISTRACTED" if distracted else "SAFE"
                st.session_state.distraction_seconds = int(duration)
                st.session_state.distraction_reason = ", ".join(reasons) if reasons else "-"

                # --- draw status banner on the video ---
                color = (0, 0, 255) if distracted else (0, 180, 0)
                cv2.putText(frame, "DISTRACTED" if distracted else "SAFE", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, color, 3)
                video_ph.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), channels="RGB",
                               use_container_width=True)

                # --- status text (matches the sample layout in the brief) ---
                status_ph.markdown(
                    f"### Driver Status: {'🔴 DISTRACTED' if distracted else '🟢 SAFE'}\n"
                    f"**Distraction Duration:** {int(duration)} seconds  \n"
                    f"**Reason:** {', '.join(reasons) if reasons else 'Driver attentive'}"
                )

                # --- warnings ---
                if distracted and duration >= st.session_state.threshold:
                    alert_ph.error("🚨 ALERT: Please focus on the road!")
                    if not alert_fired:
                        alert_fired = True
                        st.session_state.distraction_events += 1
                        st.session_state.event_log.insert(
                            0, f"{datetime.now():%I:%M:%S %p} - {st.session_state.distraction_reason}"
                        )
                        st.toast("🚨 Please focus on the road!", icon="⚠️")
                elif distracted:
                    alert_ph.warning("⚠️ Warning: Please focus on the road!")
                else:
                    alert_ph.success("✅ Driver attentive")

                time.sleep(0.03)
        finally:
            if cap is not None:
                cap.release()


# ----------------------------------------------------------------------------
# PAGE: ACCIDENT DETECTION
# ----------------------------------------------------------------------------
elif page == "🚨 Accident Detection":
    hero("🚨 Accident Detection", "Simulated detection for the hackathon demo")
    metric_row()

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Option A - Manual simulation")
        severity = st.select_slider("Severity", ["Minor", "Moderate", "Critical"], value="Critical")
        if st.button("💥 Simulate Accident", type="primary", use_container_width=True):
            trigger_accident(severity, "Manual simulation")
            st.rerun()

    with c2:
        st.subheader("Option B - Upload road image")
        up = st.file_uploader("Accident / road image", type=["jpg", "jpeg", "png"])
        if up:
            st.image(Image.open(up), use_container_width=True)
            if st.button("🔍 Analyze image", use_container_width=True):
                # Prototype: image analysis is simulated (no heavy model needed)
                with st.spinner("Analyzing image..."):
                    time.sleep(1.2)
                trigger_accident(severity, "Image upload (simulated analysis)")
                st.rerun()

    st.divider()
    acc = st.session_state.accident
    if acc:
        st.error(
            f"### 🚨 ACCIDENT DETECTED\n\n"
            f"**Location:** {acc['location']}  \n"
            f"**Time:** {acc['time']}  \n"
            f"**Severity:** {acc['severity']}  \n"
            f"**Status:** {acc['status']}  \n"
            f"**Detected via:** {acc['source']}"
        )
    else:
        st.success("✅ No accident detected. Road is clear.")


# ----------------------------------------------------------------------------
# PAGE: EMERGENCY DASHBOARD
# ----------------------------------------------------------------------------
elif page == "🗺️ Emergency Dashboard":
    hero("🗺️ Emergency Dashboard", "Control-room view of vehicle, accident and response")
    metric_row()
    acc = st.session_state.accident

    col_a, col_b, col_c = st.columns(3)
    with col_a:
        st.markdown("#### 🚗 Vehicle Safety")
        st.write(f"**Driver:** {st.session_state.driver_status}")
        st.write(f"**Distraction events:** {st.session_state.distraction_events}")
        st.write(f"**Accident:** {'YES' if acc else 'No'}")
    with col_b:
        st.markdown("#### 📍 Accident Information")
        if acc:
            st.write(f"**Location:** {acc['location']}")
            st.write(f"**Time:** {acc['time']}")
            st.write(f"**Severity:** {acc['severity']}")
        else:
            st.write("No active accident")
        st.write(f"**Response:** {st.session_state.response_status or 'Standby'}")
    with col_c:
        st.markdown("#### 🚑 Emergency Response")
        st.write(f"**SOS:** {'Sent' if st.session_state.sos_sent else 'Not sent'}")
        st.write(f"**Emergency contact:** {'Notified' if st.session_state.sos_sent else 'Standby'}")
        team = st.session_state.response_status
        st.write(f"**Response team:** {team if team and team != RESPONSE_NAMES[0] else ('Standby' if not team else 'Alert received')}")

    st.divider()
    map_col, ctl_col = st.columns([3, 2])

    with map_col:
        st.subheader("Accident location map")
        lat, lon = st.session_state.lat, st.session_state.lon
        fmap = folium.Map(location=[lat, lon], zoom_start=14, tiles="OpenStreetMap")
        if acc:
            folium.Marker([lat, lon], tooltip="Accident location",
                          popup=f"{acc['location']} - {acc['time']}",
                          icon=folium.Icon(color="red", icon="exclamation-sign")).add_to(fmap)
        else:
            folium.Marker([lat, lon], tooltip="Vehicle location",
                          icon=folium.Icon(color="blue", icon="road")).add_to(fmap)
        # Demo emergency-response unit placed ~1.2 km away from the vehicle
        resp_lat, resp_lon = lat + 0.0085, lon + 0.0100
        folium.Marker([resp_lat, resp_lon], tooltip="Emergency response unit (demo)",
                      icon=folium.Icon(color="green", icon="plus-sign")).add_to(fmap)
        if acc:
            folium.PolyLine([[resp_lat, resp_lon], [lat, lon]], color="green",
                            weight=4, dash_array="8").add_to(fmap)
        st_folium(fmap, height=420, use_container_width=True, returned_objects=[])
        st.caption("🔴 Accident   🟢 Emergency response unit (demo position)")

    with ctl_col:
        st.subheader("Response status")
        response_tracker()
        st.divider()
        cur = st.session_state.response_status
        choice = st.selectbox(
            "Judge control - change Response Status",
            RESPONSE_NAMES,
            index=RESPONSE_NAMES.index(cur) if cur in RESPONSE_NAMES else 0,
            disabled=not st.session_state.sos_sent,
            help="Enabled once an SOS has been sent.",
        )
        if st.session_state.sos_sent and choice != cur:
            st.session_state.response_status = choice
            st.rerun()
        if not st.session_state.sos_sent:
            st.caption("Send an SOS first to enable status changes.")


# ----------------------------------------------------------------------------
# PAGE: EMERGENCY ALERT
# ----------------------------------------------------------------------------
elif page == "📞 Emergency Alert":
    hero("📞 Emergency Alert", "Instant SOS to the emergency contact")
    acc = st.session_state.accident

    st.write(f"**Mode:** {'🧪 Demo Mode (simulated)' if st.session_state.demo_mode else '📡 Live mode (SMTP / Twilio)'}")
    st.write(f"**Emergency contact:** {st.session_state.contact_phone}")

    if st.button("🚨 Send SOS", type="primary"):
        ok, detail = send_sos()
        (st.success if ok else st.error)(detail)

    if st.session_state.sos_sent:
        loc = acc["location"] if acc else st.session_state.location_name
        st.error(
            f"### 🚨 SOS ALERT ACTIVATED\n\n"
            f"**Emergency Contact:** {st.session_state.contact_phone}  \n"
            f"**Accident Location:** {loc}  \n"
            f"**Status:** Alert Sent"
        )
        response_tracker()
    elif not acc:
        st.info("No accident yet. You can still press **Send SOS** to test the alert.")

    st.subheader("Alert history")
    if st.session_state.alert_history:
        st.dataframe(st.session_state.alert_history, use_container_width=True, hide_index=True)
    else:
        st.caption("No alerts sent yet.")
